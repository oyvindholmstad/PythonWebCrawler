This example shows a way to use Pyro without a Name server.
Look at the simplicity of the client. The only thing you need to
figure out is how to get the correct URI in the client.
This example just lets you enter it on the console.
You can copy it from the server's output.
